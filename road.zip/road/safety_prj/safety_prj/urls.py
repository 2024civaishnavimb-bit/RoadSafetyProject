from django.contrib import admin
from django.urls import path, include
from django.shortcuts import redirect

urlpatterns = [
    path('', lambda request: redirect('/safety/')),  # Redirect homepage → /safety/
    path('admin/', admin.site.urls),
    path('safety/', include('safety_app.urls')),
]