import pandas as pd
from safety_app.models import Intervention

def run():
    # Load Excel file
    df = pd.read_excel("C:/Users/vaishnavi m/Downloads/GPT_Input_DB.xlsx")

    for i, row in df.iterrows():
        Intervention.objects.create(
            serial_no = row.get("S. No", 0),
            problem = row.get("problem", ""),
            category = row.get("category", ""),
            type = row.get("type", ""),
            data = row.get("data", ""),
            code = row.get("code", ""),
            clause = row.get("clause", ""),
            reference = ""   # No reference column in Excel
        )

    print("Data Imported Successfully!")