from django.db import models

class Intervention(models.Model):
    serial_no = models.IntegerField()
    problem = models.CharField(max_length=200)
    category = models.CharField(max_length=100)
    type = models.CharField(max_length=100)
    data = models.TextField()
    code = models.CharField(max_length=50)
    clause = models.CharField(max_length=50)
    reference = models.CharField(max_length=100, blank=True)

    def __str__(self):
        return f"{self.category} - {self.problem} - {self.type}"