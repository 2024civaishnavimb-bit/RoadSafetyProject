from django import forms
from .models import Intervention

class IssueForm(forms.Form):
    problem = forms.ChoiceField(label="Problem", choices=[])
    category = forms.ChoiceField(label="Category", choices=[])
    type = forms.ChoiceField(label="Type", choices=[])

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        # Load dynamic values from DB
        self.fields['problem'].choices = [
            (p['problem'], p['problem'])
            for p in Intervention.objects.values('problem').distinct()
        ]

        self.fields['category'].choices = [
            (c['category'], c['category'])
            for c in Intervention.objects.values('category').distinct()
        ]

        self.fields['type'].choices = [
            (t['type'], t['type'])
            for t in Intervention.objects.values('type').distinct()
        ]