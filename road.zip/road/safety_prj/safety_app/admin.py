from django.contrib import admin
from .models import Intervention

# This will let you manage Intervention objects in the admin UI
admin.site.register(Intervention)