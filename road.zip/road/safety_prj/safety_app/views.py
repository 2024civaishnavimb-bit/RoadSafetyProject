from django.shortcuts import render
from .forms import IssueForm
from .models import Intervention
from groq import Groq

# Initialize Groq client
client = Groq(api_key="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")   # ← replace with your key ONLY once


def home(request):
    form = IssueForm()
    return render(request, "safety_app/home.html", {"form": form})


def get_gpt_explanation(intervention, road_type, problem, environment):
    prompt = f"""
You are a road safety expert.

Selected Issue:
- Problem: {problem}
- Category: {intervention.category}
- Type: {intervention.type}
- Environment: {environment}

Recommended Intervention:
{intervention.type}

Explain point-wise:
1. Why this intervention is correct
2. What safety guidelines support it
3. Which IRC/road standards apply
4. What impact it has on traffic safety
    """

    response = client.chat.completions.create(
        model="llama-3.3-70b-versatile",   # your working Groq model
        messages=[
            {"role": "user", "content": prompt}
        ]
    )

    return response.choices[0].message.content


def recommend(request):
    if request.method == "POST":
        form = IssueForm(request.POST)
        if form.is_valid():

            # Clean form inputs
            problem = form.cleaned_data['problem']
            category = form.cleaned_data['category']
            type_value = form.cleaned_data['type']

            # Query DB
            interventions = Intervention.objects.filter(
                problem__icontains=problem,
                category__icontains=category,
                type__icontains=type_value
            )

            if interventions.exists():
                selected = interventions.first()

                # Get AI explanation
                explanation = get_gpt_explanation(
                    selected,
                    category,
                    problem,
                    type_value
                )

                # Convert explanation into bullet points
                points = explanation.split(".")
                points = [p.strip() for p in points if p.strip()]

                return render(request, "safety_app/recommend.html", {
                    "intervention": selected,
                    "points": points,
                    "problem": problem,
                    "category": category,
                    "type": type_value
                })

            return render(request, "safety_app/recommend.html", {
                "intervention": None,
                "points": ["No matching intervention found."]
            })

    # fallback
    return render(request, "safety_app/home.html", {"form": IssueForm()})