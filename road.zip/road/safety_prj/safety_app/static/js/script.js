// static/safety_app/js/script.js
window.onload = function() {
  document.body.style.transition = 'background 0.6s';
  // Example effect: switch background after 10 seconds
  setTimeout(() => {
    document.body.style.backgroundImage = "url('https://www.google.com/imgres?q=accident&imgurl=https%3A%2F%2Fenglish.nepalnews.com%2Fwp-content%2Fuploads%2F2024%2F10%2FACCIDENT1691152311.jpg&imgrefurl=https%3A%2F%2Fenglish.nepalnews.com%2Fs%2Fnation%2Ftwo-killed-in-road-accident%2F&docid=ifbJh6RA-mofWM&tbnid=Wi_wauU1Px1xbM&vet=12ahUKEwj5gPKnzPaQAxULyzgGHcy6ObYQM3oECFQQAA..i&w=1920&h=1080&hcb=2&ved=2ahUKEwj5gPKnzPaQAxULyzgGHcy6ObYQM3oECFQQAA')";
  }, 10000);
};