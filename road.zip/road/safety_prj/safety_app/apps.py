from django.apps import AppConfig


class SafetyAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'safety_app'